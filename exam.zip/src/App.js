import React, { useState } from 'react';
import './App.css';
import SearchBar from './components/SearchBar';
import Accordion from './components/Accordion';
import ImageSlider from './components/ImageSlider';
import image1 from './assets/dadsa.jpg';
import image2 from './assets/dragon king 1.jpg';
import image3 from './assets/let.jpg';
import image4 from './assets/Neon wallpaper 1.jpg';

const data = [
  'Death',
  'Goku',
  'Naruto',
  'Shidp',
  'pizza',
  'cake',
  'Orange',
  'Peach',
  'Pear',
  'Strawberry',
];

const images = [image1, image2, image3, image4]; 
function App() {
  const [filteredData, setFilteredData] = useState(data);

  const handleSearch = (query) => {
    const filtered = data.filter(item =>
      item.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredData(filtered);
  };


  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleLogin = (e) => {
    e.preventDefault();
    console.log("Logged in with:", username, password, rememberMe);
  };
  return (

    //searchbar
    <div className="App">
      <h1>Search Bar Example</h1>
      <SearchBar data={data} onSearch={handleSearch} />
      <ul>
        {filteredData.map(item => (
          <li key={item}>{item}</li>
        ))}
      </ul>

    //Accordion
      <h1>Accordion Example</h1>
      <Accordion
        title="What is Lorem Ipsum?"
        content="Lorem ipsum is simply dummy text of the printing and typesetting industry"
      />
      <Accordion
        title="What is Lorem Ipsum?"
        content="Lorem ipsum is simply dummy text of the printing and typesetting industry"
      />
      <Accordion
        title="What is Lorem Ipsum?"
        content="Lorem ipsum is simply dummy text of the printing and typesetting industry"
      />
      <Accordion
        title="What is Lorem Ipsum?"
        content="Lorem ipsum is simply dummy text of the printing and typesetting industry"
      />
      {/* ... other accordions ... */}
      //image slider
      <div>
        <h1>Image Slider Example</h1>
        <ImageSlider images={images} />
      </div>

      //loginpage

      <div className="login-container">
      <div className="login-form">
        <h2>Login</h2>
        <form onSubmit={handleLogin}>
          <h3>USERNAME</h3>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <h3>PASSWORD</h3>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <div className="remember-forgot">
            <label>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              Remember me
            </label>
            <a href="#">Forgot Password?</a>
          </div>
          <button type="submit">Login</button>
        </form>
      </div>
      <div className="register-section">
        <h2>Welcome to Login</h2>
        <p>Don't have an account?</p>
        <button className="sign-up-button">Sign Up</button>
      </div>
    </div>
    </div>
  );
}

export default App;
